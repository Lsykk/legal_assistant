function showContent(type) {
    var dialogTab = document.querySelector('.tab[data-type="dialog"]');
    var opinionTab = document.querySelector('.tab[data-type="opinion"]');

    if (type === 'dialog') {
        document.getElementById('dialog').style.display = 'block';
        document.getElementById('opinion').style.display = 'none';
        dialogTab.classList.add('active');
        opinionTab.classList.remove('active');
    } else {
        document.getElementById('dialog').style.display = 'none';
        document.getElementById('opinion').style.display = 'block';
        dialogTab.classList.remove('active');
        opinionTab.classList.add('active');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    var tabs = document.querySelectorAll('.tab');
    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            showContent(this.getAttribute('data-type'));
        });
    });
});

function sendMessage() {
    var input = document.getElementById('chat-input');
    var message = input.value.trim();
    if (message) {
        var chatBox = document.getElementById('chat-box');
        
        // 清空现有内容
        if (chatBox.textContent.trim() === "暂无会话内容") {
            chatBox.textContent = '';
        }
        
        // 创建用户消息
        var userMessageElement = document.createElement('div');
        userMessageElement.className = 'chat-message user-message';
        userMessageElement.textContent = message;
        chatBox.appendChild(userMessageElement);
        
        // 清空输入框
        input.value = '';
        
        // 自动回复
        var replyMessage = generateReply(message);
        var replyMessageElement = document.createElement('div');
        replyMessageElement.className = 'chat-message reply-message';
        replyMessageElement.textContent = replyMessage;
        chatBox.appendChild(replyMessageElement);
        
        // 滚动到最新消息
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

function generateReply(message) {
    // 简单的自动回复逻辑，可以根据需要进行扩展
    return "这是一个自动回复: " + message;
}
